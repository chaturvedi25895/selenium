from yaml import load
import logging
from logging.handlers import TimedRotatingFileHandler
from os import path, makedirs, listdir


class AttributeDict(object):
    """Converts dictionary to access keys like attributes of a class.

    Attributes:
        data (dict): a dictionary

    Example:
        d = {'a': 1. 'b': 2}
        to access key 'a' in dictionary d the general approach is d['a']

        ad = AttributeDict({'a': 1. 'b': 2})
        key 'a' can be accessed like ad.a with AttributeDict.
    """

    def __init__(self, data):
        for key, value in data.items():
            if isinstance(value, dict):
                self.__dict__[key] = AttributeDict(value)
            else:
                self.__dict__[key] = value

    def __setitem__(self, key, value):
        self.__dict__[key] = value

    def __getitem__(self, key):
        return self.__dict__[key]


def load_yaml_config(filename, is_dict=False):
    """Reads YAML file.

    Parameters:
    filename (string): absolute or relative path of YAML file.
    is_dict (bool) default False: whether you want output in dict format
    or attribute dict format.

    Returns:
    dict: if is_dict is True
    AttributeDict: if is_dict is False
    """

    with open(filename, 'r') as fh:
        data = load(fh.read())
        if is_dict:
            return data
        return AttributeDict(data)


def get_logger(log_file):
    """Returns timed rotating logger.
    Parameters:
    log_file (string): name of the logfile

    Returns:
    logger: A logger object.
    """
    logging.basicConfig()
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.DEBUG)
    # handler = logging.FileHandler(log_file)
    handler = TimedRotatingFileHandler(log_file, when='midnight', interval=1)
    handler.setLevel(logging.DEBUG)

    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    handler.setFormatter(formatter)

    logger.addHandler(handler)

    return logger


class Logit():
    def __init__(self, logger, step, log_args=True, log_return=False):
        self.step = step
        self.logger = logger
        self.log_args = log_args
        self.log_return = log_return

    def __call__(self, f):
        def wrap(*args):
            a = [i for i in args if isinstance(i, str)]
            message = 'Performing {} step'.format(self.step)

            if self.log_args and len(a):
                message += ' with {}'.format(', '.join(a))

            self.logger.info(message)

            returned = f(*args)

            if self.log_return:
                self.logger.debug('Step {} returned {}'.format(
                    self.step, returned))

            self.logger.debug('Successfully completed {}'.format(self.step))
            return returned
        return wrap
