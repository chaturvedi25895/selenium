from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from utils import get_logger, Logit, load_yaml_config
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

from selenium.common.exceptions import NoSuchElementException
from os import path
import pandas as pd
import time
from datetime import datetime


__Initials_selector = '.merchant-initials > #merchant-initials'
__comment_selector ='#additional-comments'
__adv_search_selector = '.sprite-icn-globalNav-date .info-popup'
__search_button_selector = '#search'
__respond_selector = '.refund-type:nth-child(2)'
__sequence_selector = '.daysLeft .ng-binding'
__browse_button_selector = 'span > .attach-files > .file-upload-button'
__uploaded_text = '.ng-scope:nth-child(1) > .dispute-history-attach-files .image-file-name'
#css=.ng-scope:nth-child(2) > .dispute-history-attach-files
#__uploaded_text2= '.ng-scope:nth-child(2) .image-file-name'
#__uploaded_text3= '.ng-scope:nth-child(3) .image-file-name'
__confirm_upload = '#submit-contest'


config = load_yaml_config('./settings_3.yaml')
__home_page = config.homepage

max_retries = config.max_retries
max_sleep_time = config.wait_time

logger = get_logger(config.out_log)
error_log_file = config.error_log

@Logit(logger, 'Login', log_args=False)
def login(browser, username, password):
    """Opens Amex Home page and login.
    Parameters:
        browser (SeleniumDriver)
        username (String)
        password (String)
    """
    browser.get(__home_page)
    WebDriverWait(browser, max_sleep_time).until(
        EC.presence_of_element_located((By.ID, '_body_content')))

    browser.find_element_by_id("user_id").send_keys(username)
    browser.find_element_by_id("password").clear()
    browser.find_element_by_id("password").send_keys(password)
    browser.find_element_by_css_selector(".roundbtnbluemer").click()


@Logit(logger, 'Click on Advanced Search')
def click_advance_search(browser):
    wait = WebDriverWait(browser, max_sleep_time)

    wait.until_not(
        EC.visibility_of_element_located(
            (By.CSS_SELECTOR, '.blockUI.blockOverlay')
        )
    )
    wait.until(EC.visibility_of_element_located((
        By.CSS_SELECTOR, __adv_search_selector)))

    wait.until(EC.element_to_be_clickable((
        By.CSS_SELECTOR, __adv_search_selector)))
        

    adv_search = browser.find_element_by_css_selector(
        __adv_search_selector)
    time.sleep(2)

    adv_search.click()


@Logit(logger, 'Search for Merchant Order')
def search_merchant_order(browser, order_id):
    WebDriverWait(browser, max_sleep_time+10).until(EC.visibility_of_element_located(
            (By.ID, 'chrgRefNbr')))
    browser.find_element_by_id('chrgRefNbr').clear()
    time.sleep(2)
    browser.find_element_by_id('chrgRefNbr').send_keys(order_id)
    time.sleep(1)
    browser.find_element_by_css_selector(__search_button_selector).click()



@Logit(logger, 'Expand Dispute tab')
def open_dashboard(browser):
    wait = WebDriverWait(browser, max_sleep_time)
    wait.until_not(EC.visibility_of_element_located(
            (By.CSS_SELECTOR, '.blockUI.blockOverlay')))
    time.sleep(2)
    wait.until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, __sequence_selector)))
    time.sleep(2)
    browser.find_element_by_css_selector(__sequence_selector).click()
    #browser.find_element_by_xpath(__sequence_selector).click()

@Logit(logger, 'Scroll Up')
def scroll_UP(browser):
    body = browser.find_element_by_xpath('/html/body')
    body.click()
    ActionChains(browser).send_keys(Keys.PAGE_UP).perform()
    

@Logit(logger, 'Click respond')
def respond_click(browser):
    wait = WebDriverWait(browser, max_sleep_time)
    wait.until_not(EC.visibility_of_element_located(
            (By.CSS_SELECTOR, '.blockUI.blockOverlay')))
    wait.until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, __respond_selector)))

    browser.find_element_by_css_selector(__respond_selector).click()

@Logit(logger, 'Enter comment')
def comment_enter(browser):
    wait = WebDriverWait(browser, max_sleep_time)
    wait.until_not(EC.visibility_of_element_located(
            (By.CSS_SELECTOR, '.blockUI.blockOverlay')))
    wait.until(EC.element_to_be_clickable(
            (By.CSS_SELECTOR, __comment_selector)))

    browser.find_element_by_css_selector(__comment_selector).send_keys("Evidence being sent of valid charge")



@Logit(logger, 'Enter Initials')
def Initials_enter(browser):
    wait = WebDriverWait(browser, max_sleep_time)
    #wait.until_not(EC.visibility_of_element_located(
            #(By.CSS_SELECTOR, '.blockUI.blockOverlay')))
    #wait.until(EC.element_to_be_clickable(
            #(By.CSS_SELECTOR, __Initials_selector)))

    browser.find_element_by_name('merchantInitials')#.click()
    browser.find_element_by_name('merchantInitials').send_keys("KK")

@Logit(logger, 'Check in Event History', log_return=True)
def is_in_event_history(browser):
    #WebDriverWait(browser, max_sleep_time).until(
        #EC.visibility_of_element_located((By.ID, 'event-history-table')))
    try:
        browser.find_element_by_css_selector(__uploaded_text)

    except NoSuchElementException:
        return False
    return True


@Logit(logger, 'Whether Document uploaded', log_return=True)
def is_doc_uploaded(browser, order_id):
    #documentation = is_in_documentation(browser, order_id)
    event_history = is_in_event_history(browser)
    #event_history = True

    return event_history

@Logit(logger, 'Upload the document')
def upload_doc(browser, doc):
    wait = WebDriverWait(browser, max_sleep_time+3)
    wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, __browse_button_selector)))

    browser.find_element_by_id('fileupload').send_keys(doc)
    time.sleep(2)


@Logit(logger, 'Submitting the document')
def submit_doc(browser):
    WebDriverWait(browser, max_sleep_time)
    #wait.until_not(EC.visibility_of_element_located(
            #(By.CSS_SELECTOR,__confirm_upload)))
    cnfrm_btn_id = 'submit-contest'

    WebDriverWait(browser, max_sleep_time+10).until(
        EC.element_to_be_clickable(
            (By.ID, cnfrm_btn_id)
        )
    )
    time.sleep(2)

    browser.find_element_by_id(cnfrm_btn_id).click()


def search_for_merchant(browser, order_id):
    """Performs following steps
    Clicks on advance search link
    Searches for Merchant Order
    Clicks on checkbox
    Opens the dashboard."""

    # time.sleep(max_sleep_time)
    scroll_UP(browser)
    click_advance_search(browser)
    search_merchant_order(browser, order_id)
    open_dashboard(browser)
    scroll_UP(browser)

    


@Logit(logger, 'Verifying the upload of document')
def verify_upload(browser, order_id, file_name):
    """Verifies whether the document has been uploaded or not.
    If not uploaded raises and Exception."""
    time.sleep(1)
    #open_dashboard(browser)
    #browser.get(__home_page)
    #search_for_merchant(browser, order_id)
    time.sleep(2)
    if not is_doc_uploaded(browser, order_id):
        raise Exception('Document was not uploaded successfully for merchant order {}.'.format(order_id))
    else:
        logger.info('Document has been uploaded and verified for merchant order {}.'.format(order_id))


@Logit(logger, 'Processing the document')
def upload(browser, order_id, file_name):
    """Performs following steps
    Clicks respond
    Attaches the document
    Enters comments
    Enters Initials
    Submits the document
    Raise Exception if document is not uploaded."""

    # time.sleep(max_sleep_time)

    if not is_doc_uploaded(browser, order_id):
        time.sleep(1)
        respond_click(browser)
        upload_doc(browser, path.abspath(file_name))
        comment_enter(browser)
        Initials_enter(browser)
        submit_doc(browser)
        verify_upload(browser, order_id, file_name)


def save_error(order_id):
    try:
        file_mode = 'a' if path.exists(error_log_file) else 'w'
        with open(error_log_file, file_mode) as fh:
            fh.write(order_id + '\n')
    except:
        logger.error(
            'Failed to log merchant order : {} into {}'.format(
                order_id, error_log_file), exc_info=True)


def run_workflow(browser, order_id, file_name, retry=0, status='Success'):
    try:
        search_for_merchant(browser, order_id)
        upload(browser, order_id, file_name)
    except:
        logger.error('Error.', exc_info=True)
        if retry < max_retries:
            logger.info('Retrying {} to upload the Merchant order {}'.format(
                retry + 1, order_id))
            retry += 1
            try:
                browser.find_element_by_id("password")
                login(browser, config.login.uname, config.login.pwd)
                retry = 0
            except NoSuchElementException:
                pass
            run_workflow(browser, order_id, file_name, retry)
        else:
            save_error(order_id)
            status = 'Fail'
            logger.info('Failed uploading Merchant Order {}'.format(order_id))

    return status


def run(v, browser):
    order_id = v[config.mo_id_col]
    file_name = '{}.pdf'.format(order_id)
    file_name = path.join(config.mo_docs_folder, file_name)
    status = run_workflow(browser, order_id, file_name)

    return status


if __name__ == '__main__':
    browser = webdriver.Chrome(config.driver_url)
    browser.implicitly_wait(max_sleep_time)

    mos_data = pd.read_csv(config.input_csv)#.head(2)

    status_file = 'status.csv'
    try:
        status_file = '{}_{}.csv'.format(path.splitext(config.input_csv)[0], datetime.now().strftime('%Y-%m-%d-%H-%M-%S'))
    except:
        pass

    try:
        logger.info('Starting Chrome Webdriver')
        login(browser, config.login.uname, config.login.pwd)
        mos_data['Status'] = mos_data.apply(run, axis=1, args=(browser,))
    except:
        logger.error('Terminated with Exception.', exc_info=True)
    finally:
        mos_data.to_csv(status_file, index=False)
        logger.info('Generated Status File: {}'.format(status_file))
        browser.quit()
